from queue import LifoQueue


# para el tipo pila de enteros, usar: "pila: LifoQueue". La notación "pila: LifoQueue[int]" no funciona.
def calcular_expresion(expr: str) -> float:
    # implementar función con el TAD Pila
    return 0
    
    
# if __name__ == '__main__':
#   x = input() # Por ejemplo: 2 5 * 7 +
#   print(round(calcular_expresion(x), 5))

