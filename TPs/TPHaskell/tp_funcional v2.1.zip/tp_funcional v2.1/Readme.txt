Contenido entregado por la cátedra para el TP
*********************************************

-enunciado.pdf: contiene el enunciado del tp, junto con las consignas, las aclaraciones y la especificación de los ejercicios a resolver.

-iap1-tp.hs: contiene datos de la entrega a completar, las definiciones de los tipos de datos que componen de la red social, funciones básicas y las signaturas de los programas a entregar.

-test-catedra.hs: contiene los casos de prueba entregados por la cátedra que se deben pasar con éxito para poder hacer la entrega. Se deben utilizar estos test para validar su propia solución. Recuerden que además deben entregar sus propios casos de prueba.
